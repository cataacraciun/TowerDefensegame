/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// Fisier: entitati/Proiectil.java
package entitati;

import java.awt.*;

public class Proiectil {
    int x, y;
    Enemy target;
    int speed = 5;
    int damage;
    boolean specialEffect = false;
    int explosionTimer = 0;
    boolean exploded = false;

    public Proiectil(int x, int y, Enemy target, int damage) {
        this.x = x;
        this.y = y;
        this.target = target;
        this.damage = damage;
    }

    public void setSpecialEffect(boolean value) {
        this.specialEffect = value;
    }

    public void move() {
        if (exploded) {
            explosionTimer++;
            return;
        }

        int dx = target.getX() - x;
        int dy = target.getY() - y;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist != 0) {
            x += (int) (speed * dx / dist);
            y += (int) (speed * dy / dist);
        }
    }

    public boolean hasHitTarget() {
        if (exploded) return false;
        int dx = target.getX() - x;
        int dy = target.getY() - y;
        return Math.sqrt(dx * dx + dy * dy) < 10;
    }

    public boolean shouldBeRemoved() {
        return exploded && explosionTimer > 2;
    }

    public void triggerExplosion() {
        exploded = true;
    }

    public void draw(Graphics g) {
        if (exploded && specialEffect) {
            g.setColor(Color.ORANGE);
            g.fillOval(x - 10, y - 10, 20, 20);
            g.setColor(Color.RED);
            g.drawOval(x - 15, y - 15, 30, 30);
        } else if (!exploded) {
            if (specialEffect) {
                g.setColor(Color.RED);
                g.fillOval(x - 5, y - 5, 12, 12);
                g.setColor(Color.ORANGE);
                g.drawOval(x - 7, y - 7, 16, 16);
            } else {
                g.setColor(Color.BLACK);
                g.fillOval(x - 3, y - 3, 6, 6);
            }
        }
    }

    public int getDamage() {
        return specialEffect ? damage + 10 : damage;
    }

    public Enemy getTarget() {
        return target;
    }
}