/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitati;

import javax.swing.ImageIcon;
import java.awt.*;
import java.util.ArrayList;
import resources.sounds;

public class Tower {
    int x, y;
    int range = 300;
    int damage = 20;
    int fireCooldown = 0;
    boolean upgraded = false;
    private static final Image towerImg = new ImageIcon(Tower.class.getResource("/resources/tower.png")).getImage();

    public Tower(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void draw(Graphics g) {
        g.drawImage(towerImg, x, y, 70, 70, null);
        if (upgraded) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.PINK);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawOval(x, y, 70, 70);
        }
    }

    public void attack(ArrayList<Enemy> enemies, ArrayList<Proiectil> proiectile) {
        if (fireCooldown > 0) {
            fireCooldown--;
            return;
        }

        for (Enemy enemy : enemies) {
            int dx = enemy.getX() - x;
            int dy = enemy.getY() - y;
            if (Math.sqrt(dx * dx + dy * dy) < range) {
                Proiectil p = new Proiectil(x + 20, y + 20, enemy, damage);

                // Doar turnurile upgradate trag cu efect special
                if (upgraded) {
                    p.setSpecialEffect(true);  // proiectil roșu și exploziv
                }

                proiectile.add(p);
                sounds.playShootSound();

                fireCooldown = 30;
                break;
            }
        }
    }

    public boolean containsPoint(int xClick, int yClick) {
        return xClick >= x && xClick <= x + 70 &&
               yClick >= y && yClick <= y + 70;
    }


    public boolean isUpgraded() {
        return upgraded;
    }

    public void upgrade() {
        if (!upgraded) {
            upgraded = true;
            damage += 20;
            range += 50;
            sounds.playUpgradeSound();
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}


