/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entitati;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class Enemy {
    protected int x, y;
    protected int health;
    protected int speed;
    protected int currentWaypointIndex = 0;
    private static final Image enemyImg;
    private static final ArrayList<Point> waypoints = new ArrayList<>();

    static {
        try {
            enemyImg = new ImageIcon(Enemy.class.getResource("/resources/enemy.png")).getImage();
        } catch (Exception e) {
            System.err.println("Eroare încărcare enemy.png");
            throw new RuntimeException(e);
        }

        waypoints.clear();
        waypoints.add(new Point(-50, 400));  // în afara ecranului, pe stânga
        waypoints.add(new Point(300, 400));  // dreapta
        waypoints.add(new Point(300, 200));  // sus
        waypoints.add(new Point(600, 200));  // dreapta
        waypoints.add(new Point(600, 500));  // jos
        waypoints.add(new Point(975, 500));  // dreapta - ieșire
    }

    public Enemy(int x, int y, int wave) {
        this.x = x;
        this.y = y;
        this.health = 100 + (wave - 1) * 60; // crește HP cu +50 pentru fiecare wave în plus
        this.speed = Math.min((int)(3 + wave * 0.3), 10);
    }

    public void move() {
        if (currentWaypointIndex >= waypoints.size()) return;

        Point target = waypoints.get(currentWaypointIndex);
        int dx = target.x - x;
        int dy = target.y - y;
        double dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 5) {
            currentWaypointIndex++;
        } else if (dist > 0) {
            x += (int) (speed * dx / dist);
            y += (int) (speed * dy / dist);
        }
    }

    public boolean hasExited(int width) {
        return currentWaypointIndex >= waypoints.size() || x > width;
    }

    public boolean isDead() {
        return health <= 0;
    }

    public void takeDamage(int dmg) {
        health -= dmg;
    }

    public void draw(Graphics g) {
        g.drawImage(enemyImg, x, y, 60, 60, null);
        g.setColor(Color.BLACK);
        g.drawString("HP: " + health, x, y - 5);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getReward() { return 10; }

    public static ArrayList<Point> getWaypoints() {
        return waypoints;
    }

    public static void drawPath(Graphics g) {
        g.setColor(new Color(0, 100, 0)); // verde inchis
        for (int i = 0; i < waypoints.size() - 1; i++) {
            Point p1 = waypoints.get(i);
            Point p2 = waypoints.get(i + 1);
            g.drawLine(p1.x + 25, p1.y + 25, p2.x + 25, p2.y + 25);
        }
    }
}