/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game;

import entitati.Enemy;
import entitati.Tower;
import entitati.Proiectil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;

public class TowerDefenseGame extends JPanel implements ActionListener, MouseListener {
    Timer timer;
    ArrayList<Enemy> enemies = new ArrayList<>();
    ArrayList<Tower> towers = new ArrayList<>();
    ArrayList<Proiectil> proiectile = new ArrayList<>();
    Tower selectedTower = null;
    int spawnTimer = 0;
    int spawnInterval = 90;
    int score = 0;
    int wave = 1;
    int enemiesSpawned = 0;
    int enemiesPerWave = 10;
    boolean waitingForNextWave = false;
    int waitTime = 0;
    boolean playedStartSound = false;
    int lives = 5;
    boolean gameOver = false;
    boolean isPlacingTower = false;
    private Image backgroundImg;
    private Image princessImg;


    JButton restartButton = new JButton("Restart Game");
    JButton upgradeButton = new JButton("Upgrade Tower (-100)");
    JButton buyTowerButton = new JButton("Buy New Tower (-50)");

    public TowerDefenseGame() {
        setPreferredSize(new Dimension(1000, 800));
        
        try {
            backgroundImg = new ImageIcon(getClass().getResource("/resources/background.png")).getImage();
        } catch (Exception e) {
            backgroundImg = null;
        }
        try {
            princessImg = new ImageIcon(getClass().getResource("/resources/princess.png")).getImage();
        } catch (Exception e) {
            princessImg = null;
        }


        timer = new Timer(30, this);
        timer.start();

        towers.add(new Tower(375, 300));
        addMouseListener(this);

        restartButton.setBounds(320, 340, 150, 40);
        restartButton.setVisible(false);
        restartButton.addActionListener(e -> restartGame());
        add(restartButton);

        upgradeButton.setBounds(600, 20, 180, 30);
        upgradeButton.addActionListener(e -> {
            if (selectedTower == null) {
                JOptionPane.showMessageDialog(this, "Select a tower first!");
            } else if (selectedTower.isUpgraded()) {
                JOptionPane.showMessageDialog(this, "Tower already upgraded!");
            } else if (score < 100) {
                JOptionPane.showMessageDialog(this, "You need 100 points to upgrade.");
            } else {
                selectedTower.upgrade();
                score -= 100;
            }
        });
        add(upgradeButton);

        buyTowerButton.setBounds(600, 60, 180, 30);
        buyTowerButton.addActionListener(e -> {
            if (gameOver) {
                JOptionPane.showMessageDialog(this, "Game Over! Press Restart.");
            } else if (score < 50) {
                JOptionPane.showMessageDialog(this, "You need 50 points to buy a tower.");
            } else {
                isPlacingTower = true;
            }
        });
        add(buyTowerButton);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (backgroundImg != null)
            g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), null);
        else {
            g.setColor(Color.GRAY);
            g.fillRect(0, 0, getWidth(), getHeight());
        }
        if (princessImg != null) {
            java.util.List<Point> waypoints = Enemy.getWaypoints();
            if (!waypoints.isEmpty()) {
                Point end = waypoints.get(waypoints.size() - 1);
                int width = 70;
                int height = 110;
                g.drawImage(princessImg, end.x - width / 2, end.y - height - 10, width, height, null);
            }
        }


        Enemy.drawPath(g);

        for (Tower tower : towers) tower.draw(g);
        for (Enemy enemy : enemies) enemy.draw(g);
        for (Proiectil p : proiectile) p.draw(g);

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString("Score: " + score, 10, 20);
        g.drawString("Wave: " + wave, 10, 40);
        g.drawString("Lives: " + lives, 10, 60);

        if (gameOver) {
            String gameOverText = "Game Over!";
            Font font = new Font("Arial", Font.BOLD, 48);
            g.setFont(font);
            FontMetrics fm = g.getFontMetrics();
            int textWidth = fm.stringWidth(gameOverText);
            int textHeight = fm.getHeight();

            int boxWidth = textWidth + 40;
            int boxHeight = textHeight + 30;
            int boxX = (getWidth() - boxWidth) / 2;
            int boxY = getHeight() / 2 - boxHeight / 2;

            // fundalul chenarului
            g.setColor(new Color(0, 0, 0, 180)); // semi-transparent negru
            g.fillRoundRect(boxX, boxY, boxWidth, boxHeight, 20, 20);

            // marginea chenarului
            g.setColor(Color.RED);
            g.drawRoundRect(boxX, boxY, boxWidth, boxHeight, 20, 20);

            // textul Game Over
            g.setColor(Color.WHITE);
            g.drawString(gameOverText, boxX + (boxWidth - textWidth) / 2, boxY + (boxHeight + textHeight / 2) / 2);
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (gameOver) {
            restartButton.setVisible(true);
            return;
        }

        spawnInterval = Math.max(120 - wave * 5, 30);

        if (waitingForNextWave) {
            waitTime++;
            if (waitTime >= 150) {
                waitingForNextWave = false;
                waitTime = 0;
                spawnTimer = spawnInterval;
            }
        } else {
            spawnTimer++;
            if (spawnTimer >= spawnInterval && enemiesSpawned < enemiesPerWave) {
                Point start = Enemy.getWaypoints().get(0);
                enemies.add(new Enemy(start.x, start.y, wave));
                enemiesSpawned++;
                spawnTimer = 0;
            }
        }

        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy enemy = it.next();
            enemy.move();
            if (enemy.hasExited(getWidth())) {
                it.remove();
                lives--;
                if (lives <= 0) gameOver = true;
            } else if (enemy.isDead()) {
                it.remove();
                score += enemy.getReward();
            }
        }

        if (enemiesSpawned >= enemiesPerWave && enemies.isEmpty() && !waitingForNextWave) {
            wave++;
            enemiesSpawned = 0;
            enemiesPerWave += 5;
            waitingForNextWave = true;
        }

        for (Tower tower : towers) tower.attack(enemies, proiectile);

        proiectile.removeIf(p -> {
            p.move();
            if (p.hasHitTarget()) {
                p.getTarget().takeDamage(p.getDamage());
                return true;
            }
            return p.shouldBeRemoved();
        });

        repaint();
    }

    public void restartGame() {
        score = 0;
        wave = 1;
        enemiesSpawned = 0;
        enemiesPerWave = 10;
        lives = 5;
        gameOver = false;
        selectedTower = null;
        isPlacingTower = false;
        enemies.clear();
        proiectile.clear();
        towers.clear();
        towers.add(new Tower(375, 300));
        restartButton.setVisible(false);
    }

    public void mouseClicked(MouseEvent e) {
        if (gameOver) return;
        int x = e.getX(), y = e.getY();

        if (isPlacingTower && score >= 50) {
            if (isValidTowerPosition(x, y)) {
                towers.add(new Tower(x, y));
                score -= 50;
                isPlacingTower = false;
            } else {
                JOptionPane.showMessageDialog(this, "Invalid position.");
            }
            return;
        }

        selectedTower = null;
        for (Tower tower : towers)
            if (tower.containsPoint(x, y)) {
                selectedTower = tower;
                break;
            }
    }

    private boolean isValidTowerPosition(int x, int y) {
        for (Point wp : Enemy.getWaypoints()) {
            if (wp.distance(x, y) < 50) return false;
        }
        for (Tower tower : towers) {
            if (Math.abs(tower.getX() - x) < 40 && Math.abs(tower.getY() - y) < 40)
                return false;
        }
        return true;
    }

    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Tower Defense Game");
        TowerDefenseGame game = new TowerDefenseGame();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}